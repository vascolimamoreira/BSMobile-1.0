$(window).load(function(){
        
    $("#BIncidentes_Sair").click(function()
    {

        window.location.replace("menu.html");
        
    });
                             
});     