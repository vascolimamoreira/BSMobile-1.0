$(window).load(function(){
        
    $("#BMenu_Clientes").click(function()
    {

        window.location.replace("clientes.html");
        
    });
       
    $("#BMenu_Pendentes").click(function()
    {

        window.location.replace("pendentes.html");
        
    });
       
    
//    $("#BMenu_Incidentes").click(function()
//    {
//
//        window.location.replace("incidentes.html");
//        
//    });
       
    
    $("#BMenu_Sair").click(function()
    {

        window.location.replace("index.html");
        
    });
                             
}); 