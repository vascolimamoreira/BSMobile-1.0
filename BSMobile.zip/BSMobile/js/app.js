$(window).load(function(){
        
//    $("#BMain_Entrar").click(function()
//    {
//
//        window.location.replace("menu.html");
//        
//    });
//                             
}); 